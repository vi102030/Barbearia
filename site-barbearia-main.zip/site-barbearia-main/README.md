<h1>Site Barbearia</h1>

> Status do projeto: Em desenvolvimento.

>  Para rodar esse projeto em sua máquina , por favor instalar:

```
Sublime ou Visual Studio Code - HTML - CSS - JAVASCRIPT
```
